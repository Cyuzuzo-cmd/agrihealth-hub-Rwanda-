# Agri-Health Hub Rwanda — NISR Big Data Hackathon 2026

**Track:** Track 1 — Agricultural Productivity

## Project summary
Agri-Health Hub Rwanda is a proposed sustainable vegetable-farming, irrigation-planning and composting initiative. This deployable website includes an early Smart Agriculture Data Prototype that turns selected published NISR Seasonal Agricultural Survey indicators into a simple dashboard and farmer-entered planning calculators.

## Prototype features
- Latest published NISR SAS Season A 2026 national indicators: irrigation, anti-erosion practices, agroforestry, mechanisation, improved seeds, organic/inorganic fertiliser and pesticide use.
- Historical Season A / Season B 2025 input-use comparisons.
- Harvest arithmetic calculator using user-entered farm area and expected yield.
- Compost output arithmetic calculator using a user-entered conversion assumption.
- Browser-local farm activity log (no server submission).
- Links to NISR publications and the SAS microdata catalogue.

## Data provenance
Primary source: National Institute of Statistics of Rwanda (NISR), Seasonal Agricultural Survey (SAS), Season A 2026 and Annual Report 2025. The 2026 Season A release reports 14.4% irrigation practice, 92.4% anti-erosion practice, 53.4% agroforestry, 1.7% mechanisation, 37.0% improved-seed use, 90.2% organic-fertiliser use, 67.2% inorganic-fertiliser use and 46.9% pesticide use.

Source URLs:
- https://www.alpha.statistics.gov.rw/statistical-publications/agriculture-environment/seasonal-agricultural-survey-season-2026
- https://www.gis.statistics.gov.rw/data-sources/surveys/Seasonal-Agricultural-Survey/Seasonal-Agricultural-Survey/seasonal-agricultural-survey-2025-
- https://www.microdatabk.statistics.gov.rw/catalog/124
- https://www.statistics.gov.rw/data-sources/surveys/Seasonal-Agricultural-Survey

The dashboard uses published national summary indicators. It does not yet download, clean or analyse SAS microdata and does not show district-level estimates.

## Methodology and limitations
- Published survey percentages are descriptive statistics; they do not establish causation or crop-specific recommendations.
- Season A 2026 and 2025 indicators are survey results for their stated periods, not live farm readings.
- Harvest estimate = area (ha) × user-entered expected yield (kg/ha).
- Compost estimate = suitable biodegradable waste (kg) × user-entered conversion percentage / 100.
- Farm activity records are stored in the visitor's browser localStorage only. There is no central database, authentication, multi-user sync or server-side collection.
- No machine-learning prediction, live weather feed, satellite analysis, sensor integration or automated alert service is implemented.

## AI-use disclosure
AI assistance was used to help research public documentation, draft explanatory text and code parts of this website prototype. The student team must review and test the code, verify all statistics against the cited NISR publications, acknowledge all sources and remain responsible for the final submission.

## Run locally
Open `index.html` in a modern web browser. No build step or package installation is required.

## Deployment
Upload the contents of this ZIP to the existing Netlify site using Netlify's manual deploy / deploy folder workflow. Keep `index.html` and `agri-health-hub-rwanda-project.pdf` at the published site root.

## Team and submission checklist
Project team: C&C_ECO Innovators. Before submission, verify all team-member names, add the public GitHub repository URL, test the deployed app on desktop and mobile, and ensure the public repository and documentation match the deployed version.
